subor = open("majstrovstva.txt", "r")


prvy_riadok = subor.readline().split()
S = int(prvy_riadok[0])
R = int(prvy_riadok[1])

vysledky = []

for i in range(S):
    meno = subor.readline().strip()
    znamky = list(map(int, subor.readline().split()))

    znamky.remove(max(znamky))
    znamky.remove(min(znamky))

    body = sum(znamky)
    vysledky.append((body, meno))

subor.close()


vysledky.sort(reverse=True)


for body, meno in vysledky:
    print(body, meno)
