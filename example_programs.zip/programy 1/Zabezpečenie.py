f = open("zasifrovany.txt", "r")

n = int(f.readline())
p = f.readline().strip()

text = []
for i in range(n):
    text.append(f.readline().rstrip())

f.close()

# prvé písmeno textu (nie medzera)
for z in text[0]:
    if z != " ":
        prve = z
        break

k = ord(prve) - ord(p)
k = k % 26

for riadok in text:
    novy = ""
    for z in riadok:
        if z == " ":
            novy += " "
        else:
            c = ord(z) - k
            if c < ord("A"):
                c += 26
            novy += chr(c)
    print(novy)