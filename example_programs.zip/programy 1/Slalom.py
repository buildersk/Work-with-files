subor = open("slalom.txt", "r", encoding="utf-8")
pocet = int(subor.readline())

vysledky = []

for i in range(pocet):

    riadok = subor.readline().split()
    meno = riadok[0]
    stat = riadok[1]
    cas = riadok[2]
    
    vysledky.append([cas, meno, stat])

    vysledky.sort()

    print("\nVýstup po načítaní", i + 1, ". súťažiacej:")
    for j in range(len(vysledky)):
        
        print(j + 1, ".", vysledky[j][1], vysledky[j][2], vysledky[j][0])

subor.close()
