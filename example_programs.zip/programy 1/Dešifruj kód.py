import random

dlzka = random.randint(3, 6)
kod = []

for i in range(dlzka):
    kod.append(str(random.randint(0, 9)))

uhadnute = ["*"] * dlzka
pocet_pokusov = 0
print("Kód >>", " ".join(uhadnute))

while uhadnute != kod:
    vstup = input("\nZadaj kód: ")
    if len(vstup) != dlzka:
        print("Musíš zadať", dlzka, "číslic.")
        continue

    pocet_pokusov += 1

    for i in range(dlzka):
        if vstup[i] == kod[i]:
            uhadnute[i] = vstup[i]

    print("Kód >>", " ".join(uhadnute))

print("\nUhádol si správny kód.")
print("Počet pokusov:", pocet_pokusov)