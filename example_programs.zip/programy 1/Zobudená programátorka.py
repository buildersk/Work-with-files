n = int(input("Zadaj potrebnú hmotnosť kávy: "))

vrecuska = []
mocnina = 1

while n > 0:
    if n % 2 == 1:
        vrecuska.append(mocnina)
    n //= 2
    mocnina *= 2

for v in vrecuska:
    print(v, end=" ")
