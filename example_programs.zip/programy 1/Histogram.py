# histogram
import random
cisla = []
for i in range(10):
    cisla.append(random.randint(1,9))
for vyska in range(9, 0, -1):
    riadok = ""
    for n in cisla:
        if n >= vyska:
            riadok += "* "
        else:
            riadok += "  "
    print(riadok)
print(*cisla)
