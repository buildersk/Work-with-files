n=int(input("zadaj cislo v 10sustave >> "))
binar=bin(n)[2:]
poc=0
print(f"cislo {n} v 2sustave >> {binar}")
for i in binar:
    if int(i)==1:
        poc+=1
print(f"pocet vyskytnutých jednotiek >> {poc}")