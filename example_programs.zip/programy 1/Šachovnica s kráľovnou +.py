def Dama(x, y):

    x -= 1
    y -= 1

    for i in range(8):
        riadok = ""
        for j in range(8): 
            
            if i == x and j == y:
                riadok += "D " # Tu stojí dáma
            elif i == x or j == y or abs(x - i) == abs(y - j):
                riadok += "* " 
            else:
                riadok += ". " 
        
        print(riadok)

print("Pozícia dámy: 3, 5")
Dama(3, 5)