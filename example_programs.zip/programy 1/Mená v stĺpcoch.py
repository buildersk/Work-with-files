subor = open("zamestnanci.txt", "r", encoding="utf-8")
riadky = subor.read().splitlines()
subor.close()

pocet = len(riadky) // 2
print("Počet mien v súbore:", pocet)

mena = []
priezviska = []

for i in range(pocet):
    mena.append(riadky[i])

for i in range(pocet, 2*pocet):
    priezviska.append(riadky[i])

najdlhsie_meno = 0
for m in mena:
    if len(m) > najdlhsie_meno:
        najdlhsie_meno = len(m)

najdlhsie_priezvisko = 0
for p in priezviska:
    if len(p) > najdlhsie_priezvisko:
        najdlhsie_priezvisko = len(p)

print("Najdlhšie krstné meno má dĺžku:", najdlhsie_meno)
print("Najdlhšie priezvisko má dĺžku:", najdlhsie_priezvisko)

vys = open("zoznam.txt", "w", encoding="utf-8")
for i in range(pocet):
    meno = mena[i]
    priez = priezviska[i]

    medzery = " " * (najdlhsie_meno + 3 - len(meno))
    riadok = meno + medzery + priez
    vys.write(riadok + "\n")
vys.close()


