subor = open("dialnica.txt", "r")
riadky = subor.readlines()
subor.close()

for riadok in riadky:
    print(riadok.strip())

K = int(riadky[0])     
N = int(riadky[1])         

stanice = []
for s in riadky[2].split():
    stanice.append(int(s))

pocet = 0

for i in range(N):

    for j in range(i + 1, N):
        vzdialenost = stanice[j] - stanice[i]

        if vzdialenost <= K:
            pocet = pocet + 1

print("---")
print("Výsledok:", pocet)
if pocet == 2:
    print("Prvá a tretia stanica sú vo vzdialenosti 105, čo je priveľa")
elif pocet == 10:
    print("Každé dve stanice sú vo vzdialenosti 100 alebo menej")