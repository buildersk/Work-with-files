with open("znamky1.txt", "r", encoding="utf-8") as subor:
    riadky = [r.strip() for r in subor if r.strip()]

if len(riadky) < 3:
    print("Súbor musí mať aspoň 3 riadky.")
else:
    pocet_zn = int(riadky[0])
    postup_A = list(map(int, riadky[1].split()))
    postup_B = list(map(int, riadky[2].split()))
    
    if len(postup_A) != pocet_zn:
        print(f"Chyba: riadok A má {len(postup_A)} čísel, ale očakáva sa {pocet_zn}.")
    else:
        mnozina_A = set(postup_A)
        mnozina_B = set(postup_B)
        
        navyse = mnozina_B - mnozina_A
        pocet_navyse = len(navyse)
        
        if navyse:
            print("Počet čísel navyše:", pocet_navyse)
            print("Čísla navyše v riadku B:", sorted(navyse))
        else:
            print("Žiadne čísla navyše v riadku B.")
