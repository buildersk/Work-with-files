n = int(input("Zadaj cenu: "))

sucet = 0
for cifra in str(n):
    sucet += int(cifra)

usetril = n - sucet

print("Ušetrí:", usetril, "eur")