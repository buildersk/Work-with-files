def spracuj_subor(vstup, vystup):
    pocet_hier = 0
    max_kroky = 0

    with open(vstup, "r", encoding="utf-8") as f_in, \
         open(vystup, "w", encoding="utf-8") as f_out:

        for riadok in f_in:
            hra = riadok.strip()
            if hra == "":
                continue

            pocet_hier += 1
            max_kroky = max(max_kroky, len(hra))

            
            vysledok = ""
            aktualny = hra[0]
            pocet = 1

            for znak in hra[1:]:
                if znak == aktualny:
                    pocet += 1
                else:
                    vysledok += f"{aktualny}{pocet} "
                    aktualny = znak
                    pocet = 1

            vysledok += f"{aktualny}{pocet}"

            
            f_out.write(vysledok + "\n")

    print("Počet hier:", pocet_hier)
    print("Najdlhšia hra:", max_kroky)
    print("Komprimovaný súbor uložený ako:", vystup)



spracuj_subor("hada.txt", "hada_komprimovane.txt")
