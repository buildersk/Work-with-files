with open("teploty.txt", "r", encoding="utf-8") as subor:
    teploty = []
    for riadok in subor:
        novy_riadok = []
        for hodnota in riadok.split():
            novy_riadok.append(float(hodnota))
        teploty.append(novy_riadok)

print("R O V P")

max_rano = 0
max_obed = 0
max_vecer = 0 

for den in teploty:
    rano = den[0]
    obed = den[1]
    vecer = den[2]

    priemer = (rano + obed + vecer) / 3

    print(int(rano), int(obed), int(vecer), f"{priemer:.2f}")

    if rano > max_rano:
        max_rano = rano
    if obed > max_obed:
        max_obed = obed
    if vecer > max_vecer:
        max_vecer = vecer

print("\nNajvyššia teplota:")
print(f"Rano {int(max_rano)}")
print(f"Obed {int(max_obed)}")
print(f"Vecer {int(max_vecer)}")
