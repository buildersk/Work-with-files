subor = open("skok_do_dialky.txt", "r")

krajiny = set()
pocet_krajin = {}
vitazi = []
max_skok = 0

for riadok in subor:
    data = riadok.split()
    meno = data[0]
    krajina = data[1]
    skoky = list(map(int, data[2:]))


    krajiny.add(krajina)

    if krajina in pocet_krajin:
        pocet_krajin[krajina] += 1
    else:
        pocet_krajin[krajina] = 1

 
    najlepsi = max(skoky)

    if najlepsi > max_skok:
        max_skok = najlepsi
        vitazi = [meno]
    elif najlepsi == max_skok:
        vitazi.append(meno)

subor.close()

print("Zoznam krajín:")
for k in krajiny:
    print(k)

print("\nPočty súťažiacich z krajín:")
for k in pocet_krajin:
    print(k, pocet_krajin[k])

print("\nVíťaz(i):")
for v in vitazi:
    print(v, "-", max_skok)
