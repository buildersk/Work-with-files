subor = open("trojboj_data.txt", "r", encoding="utf-8")
riadok = subor.read().strip()
subor.close()

casti = riadok.split()

pocet = len(casti) // 4
print("Počet súťažiacich:", pocet)
print()

meno_dialka = casti[0]
naj_dialka = int(casti[1])

meno_vyska = casti[0]
naj_vyska = int(casti[2])

meno_ostep = casti[0]
naj_ostep = int(casti[3])

for i in range(1, pocet):
    meno = casti[i*4]
    dialka = int(casti[i*4 + 1])
    vyska = int(casti[i*4 + 2])
    ostep = int(casti[i*4 + 3])

    if dialka > naj_dialka:
        naj_dialka = dialka
        meno_dialka = meno

    if vyska > naj_vyska:
        naj_vyska = vyska
        meno_vyska = meno

    if ostep > naj_ostep:
        naj_ostep = ostep
        meno_ostep = meno

print("Víťaz v skoku do diaľky:", meno_dialka, naj_dialka, "cm")
print("Víťaz v skoku do výšky:", meno_vyska, naj_vyska, "cm")
print("Víťaz v hode oštepom:", meno_ostep, naj_ostep, "cm")
