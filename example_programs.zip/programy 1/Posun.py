import random

N = int(input("Zadaj počet znakov (max 20): "))
if N > 20:
    N = 20

znaky = []


for i in range(N):
    znaky.append(chr(random.randint(65, 90)))


print("Vygenerované znaky:")
for z in znaky:
    print(z, end=" ")
print()


posun1 = znaky[1:] + [znaky[0]]
print("Posunuté o jeden doľava:")
for z in posun1:
    print(z, end=" ")
print()


k = int(input("Zadaj k: "))
k = k % N  

posunk = znaky[k:] + znaky[:k]
print(f"Posunuté o {k} prvkov doľava:")
for z in posunk:
    print(z, end=" ")
