subor = open("merania.txt", "r", encoding="utf-8")
riadok = subor.read().strip()
subor.close()

print("Obsah súboru:")
print(riadok)
print()

cisla = riadok.split()
cisla = [int(x) for x in cisla]

pocet_ziakov = 0
i = 0
najviac_merani = 0
sucet_pre_najviac = 0
poradie_naj = 0

while i < len(cisla):
    pocet_merani = cisla[i]
    sucet = 0
   
    for j in range(1, pocet_merani + 1):
        sucet += cisla[i + j]
    pocet_ziakov += 1

    if pocet_merani > najviac_merani:
        najviac_merani = pocet_merani
        sucet_pre_najviac = sucet
        poradie_naj = pocet_ziakov
    elif pocet_merani == najviac_merani:
        if sucet > sucet_pre_najviac:
            sucet_pre_najviac = sucet
            poradie_naj = pocet_ziakov

    i += pocet_merani + 1

print("Počet žiakov:", pocet_ziakov)
print("Žiak s najviac meraniami (alebo najväčším súčtom pri rovnosti):", poradie_naj)
