import random

# 1. NAČÍTANIE TIPOV
vstup = input("Zadaj 10 čísel oddelených medzerou: ")
# Rozbijeme text na zoznam slov
slova = vstup.split()

tipy = []
for s in slova:
    cislo = int(s)      # Zmeníme text na skutočné číslo
    tipy.append(cislo)  # Pridáme ho do nášho zoznamu tipov

# 2. ŽREBOVANIE (20 náhodných čísel)
zrebovane = []
while len(zrebovane) < 20:
    nove_cislo = random.randint(1, 80)
    # Kontrola, aby sa čísla neopakovali
    if nove_cislo not in zrebovane:
        zrebovane.append(nove_cislo)

print("Počítač vyžreboval:", zrebovane)

# 3. POROVNANIE (hľadáme zhody)
uhadnute = []
for t in tipy:
    # Ak sa tvoj tip nachádza medzi vyžrebovanými
    if t in zrebovane:
        uhadnute.append(t)

# 4. VÝSLEDOK
print("Tvoje tipy:", tipy)
print("Uhádnuté čísla:", uhadnute)
print("Počet uhádnutých čísel:", len(uhadnute))