kapacita = 0
aktualne = 0
zastavky = []
preplnene = []
max_prekrocenie = 0

with open("vytazenost.txt", "r", encoding="utf-8") as f:
    kapacita = int(f.readline())

    for riadok in f:
        nastup, vystup, *nazov = riadok.split()
        nazov = " ".join(nazov)

        aktualne += int(nastup)
        aktualne -= int(vystup)

        zastavky.append(nazov)

        if aktualne > kapacita:
            preplnene.append(nazov)
            if aktualne - kapacita > max_prekrocenie:
                max_prekrocenie = aktualne - kapacita


print("Počet zastávok:", len(zastavky))
print("Zastávky:", ", ".join(zastavky))

if preplnene:
    print("Preplnené zastávky:", ", ".join(preplnene))
    print("Najväčšie prekročenie kapacity:", max_prekrocenie)
else:
    print("Autobus nebol nikde preplnený.")
