
while True:
    print()
    n = input("Rodne cislo>> ")
    if len(n) != 10 or not n.isdigit():
        print("Zlé číslo")
        continue

    cislo = list(n)
    i = cislo[2]
    mesiace=["Januára","Februára","Marca","Apríla","Mája","Júna","Júla","Augusta","Septembera","Októbera","Novembera","Decembera"]
    
    if int(n) % 11 == 0:
        if i == "5" or i == "6":
            print("Pohlavie: Žena")
            p = int(cislo[2])
            m = p - 5
            r = int(cislo[0])
            mesiac=m+int(cislo[3])-1
            if r == 0:
                print(f"Narodená {cislo[4]}{cislo[5]}. {mesiace[mesiac]} 20{cislo[0]}{cislo[1]}")
            else:
                print(f"Narodená {cislo[4]}{cislo[5]}. {mesiace[mesiac]} 19{cislo[0]}{cislo[1]}")
        else:
            r = int(cislo[0])
            mesiac=int(cislo[2]+cislo[3])-1
            print("Pohlavie: Muž")
            if r == 0:
                print(f"Narodený {cislo[4]}{cislo[5]}. {mesiace[mesiac]} 20{cislo[0]}{cislo[1]}")
            else:
                print(f"Narodený {cislo[4]}{cislo[5]}. {mesiace[mesiac]} 19{cislo[0]}{cislo[1]}")
    