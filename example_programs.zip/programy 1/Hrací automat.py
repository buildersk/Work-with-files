import random


n=int(input("Zadaj peniaze >> "))
poc=0

while n>0 and poc!=1000:
    poc += 1
    a,b,c=random.randint(1,20),random.randint(1,20),random.randint(1,20)
    if a==b or a==c or b==c:
        n=n+5
        print("+5",end=" ")
    if a==b==c:
        n=n+100
        print("+100",end=" ")
    else:
        n=n-1
        print("-1",end=" ")
print("\n"f"Zostalo mi {n}Eur")