import random

# 1. GENERUJEME N (náhodné číslo od 3 do 8)
n = random.randint(3, 8)

# 2. VYTVORÍME POSTUPNOSŤ (napr. ak n=3, tak tri 1 a tri 0)
postupnost = []
for i in range(n):
    postupnost.append(1)
    postupnost.append(0)

# Premiešame ich, aby boli v náhodnom poradí
random.shuffle(postupnost)

print("N:", n)
print("Štart:", postupnost)
print("-" * 20)

# 3. VYTVORÍME CIEĽ (ako by to malo vyzerať: 1, 0, 1, 0...)
ciel = []
for i in range(n):
    ciel.append(1)
    ciel.append(0)

# 4. OPRAVUJEME CHYBY (hľadáme, kde je 1 namiesto 0 a naopak)
vymeny = 0

for i in range(2 * n):
    # Ak číslo na pozícii 'i' nie je také, aké má byť v cieli
    if postupnost[i] != ciel[i]:
        
        # Musíme nájsť niekoho ďalej v rade, kto má to správne číslo a vymeniť si to s ním
        for j in range(i + 1, 2 * n):
            if postupnost[j] == ciel[i]:
                # Našli sme správne číslo na pozícii 'j', tak ich vymeníme
                postupnost[i], postupnost[j] = postupnost[j], postupnost[i]
                vymeny = vymeny + 1
                
                # Vypíšeme, čo sa stalo
                print(f"Výmena {vymeny}: {postupnost}")
                break # Skočíme späť na hlavný cyklus, lebo pozícia 'i' je už opravená

print("-" * 20)
print("Celkový počet výmen:", vymeny)