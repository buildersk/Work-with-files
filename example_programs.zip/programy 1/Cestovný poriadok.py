def elektrika(zaciatok, koniec, interval):
    hodina = zaciatok
    minuta = 0

    while hodina <= koniec:
        print(f"{hodina:02d}:{minuta:02d}", end=" ")
        minuta += interval

        if minuta >= 60:
            minuta -= 60
            hodina += 1
            print() 

        
zaciatok = int(input("Zadaj začiatok premávky: "))
koniec = int(input("Zadaj koniec premávky: "))
interval = int(input("Zadaj interval v minútach: "))

elektrika(zaciatok, koniec, interval)