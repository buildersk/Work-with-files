subor = open("zamok1.txt", "r")
riadky = subor.readlines()
subor.close()

pocet = int(riadky[0].strip())
start = riadky[1].strip()
cieľ = riadky[2].strip()
print("Počet koliesok:", pocet)
print("Stav:", start, "-> Cieľ:", cieľ)

celkovo = 0

for i in range(pocet):
    s = int(start[i])
    c = int(cieľ[i])
  
    vzdialenost = abs(s - c)
  
    if vzdialenost > 5:
        otocenia = 10 - vzdialenost
    else:
        otocenia = vzdialenost
        
    celkovo += otocenia

print("Najmenší počet otočení:", celkovo)