import random

pocet_hier = int(input("Počet hier: "))

skore_ja = 0
skore_pc = 0

for i in range(1, pocet_hier + 1):
    print(f"{i}. hra:")

    print("vyberte 'k' (kameň), 'p' (papier) alebo 'n' (nožnice)")
    ja = input("Ja: ")
    moznosti = ['k', 'p', 'n']
    pc = random.choice(moznosti)
    print("PC:", pc)

    if ja == pc:
        print("Remíza v tomto kole.")
    elif (ja == 'k' and pc == 'n') or (ja == 'p' and pc == 'k') or (ja == 'n' and pc == 'p'):
        print("Tento bod získavate Vy!")
        skore_ja = skore_ja + 1
    else:
        print("Tento bod získava PC.")
        skore_pc = skore_pc + 1
    print("-" * 10)

if skore_ja > skore_pc:
    print("Vyhrali ste Vy!")
elif skore_pc > skore_ja:
    print("Vyhral počítač!")
else:
    print("Celková remíza!")

print(f"skóre: Hráč: {skore_ja}, PC: {skore_pc}")