with open("objednane_jedla1.txt", "r", encoding="utf-8") as file:
    obsah = file.read().split()

jedla = []


for i in range(1, len(obsah), 2):
    jedla.append(obsah[i])


print("Počet objednaných jedál >>", len(jedla))


oranzova = jedla.count("o")
cervena = jedla.count("c")
modra = jedla.count("m")
zelena = jedla.count("z")

print("\noranžová >>", oranzova)
print("červená >>", cervena)
print("modrá >>", modra)
print("zelená >>", zelena)

malo_objednavok = False


if oranzova < 20:
    print("Menej ako 20 objednávok má oranžová")
    malo_objednavok = True

if cervena < 20:
    print("Menej ako 20 objednávok má červená")
    malo_objednavok = True

if modra < 20:
    print("Menej ako 20 objednávok má modrá")
    malo_objednavok = True

if zelena < 20:
    print("Menej ako 20 objednávok má zelená")
    malo_objednavok = True

if malo_objednavok == False:
    print("\nKaždé jedlo malo dostatok stravníkov.")