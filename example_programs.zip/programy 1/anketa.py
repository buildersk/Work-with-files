subor = open("anketa.txt", "r", encoding="utf-8")
riadok = subor.read().strip()
subor.close()

odpovede = riadok.split(" ")

pocet_respondentov = len(odpovede)
print("Počet respondentov:", pocet_respondentov)

A_pocet = [0,0,0,0,0,0,0,0,0,0]

for odp in odpovede:
    for i in range(10):
        if odp[i] == "A":
            A_pocet[i] += 1

percenta = []
for i in range(10):
    percenta.append(A_pocet[i] / pocet_respondentov * 100)

naj = percenta[0]
for p in percenta:
    if p > naj:
        naj = p
print("Najvyššie percentá mali otázky:")

for i in range(10):
    if percenta[i] == naj:
        print(i + 1)

vystup = open("vysledky.txt", "w", encoding="utf-8")

for i in range(10):
    vystup.write(str(i+1) + ". " + f"{percenta[i]:.2f}%" + "\n")

vystup.close()


