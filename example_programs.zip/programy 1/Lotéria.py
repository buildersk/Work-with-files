import random

vylosovane = []
while len(vylosovane) < 6:
    cislo = random.randint(1, 49)
    if cislo not in vylosovane:
        vylosovane.append(cislo)

print("Vylosované čísla:", vylosovane)

pocitadla = [0, 0, 0, 0, 0, 0, 0]
subor = open("loteria.txt", "r")

for riadok in subor:
    
    casti = riadok.split()

    tip = []
    for kus in casti:
        tip.append(int(kus))

    zhody = 0
    for cislo_v_tipe in tip:
        if cislo_v_tipe in vylosovane:
            zhody = zhody + 1

    pocitadla[zhody] = pocitadla[zhody] + 1

subor.close()
print("--- VÝSLEDKY ---")
for i in range(1, 7): 
    print(i, "cisel uhadli", pocitadla[i], "tipujuci")