with open("hodnoty.txt", "r", encoding="utf-8") as f:
    obsah = f.read().strip()

print("Obsah súboru:")
print(obsah)
hodnoty = list(map(int, obsah.split()))
print("Pocet zaznamenanych hodnot:", len(hodnoty))
for i in range(len(hodnoty)):
    znak = ""
    if 0 < i < len(hodnoty) - 1 and hodnoty[i] > hodnoty[i-1] and hodnoty[i] > hodnoty[i+1]:
        znak = "+"
    elif 0 < i < len(hodnoty) - 1 and hodnoty[i] < hodnoty[i-1] and hodnoty[i] < hodnoty[i+1]:
        znak = "-"
    print(hodnoty[i], znak)
